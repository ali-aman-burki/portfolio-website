class MemberTier:
    BASIC = "Basic"
    PREMIUM = "Premium"
    STUDENT = "Student"

    LOAN_LIMITS = {BASIC: 3, PREMIUM: 10, STUDENT: 5}

    @staticmethod
    def loan_limit(tier):
        return MemberTier.LOAN_LIMITS.get(tier, 3)


class Member:
    def __init__(self, member_id, name, email, tier):
        self.member_id = member_id
        self.name = name
        self.email = email
        self.tier = tier
        self.active_loan_ids = []
        self.is_active = True

    def loan_limit(self):
        return MemberTier.loan_limit(self.tier)

    def can_borrow(self):
        return self.is_active and len(self.active_loan_ids) < self.loan_limit()

    def add_loan(self, loan_id):
        self.active_loan_ids.append(loan_id)

    def remove_loan(self, loan_id):
        if loan_id in self.active_loan_ids:
            self.active_loan_ids.remove(loan_id)
            return True
        return False

    def deactivate(self):
        self.is_active = False

    def display(self):
        status = "Active" if self.is_active else "Inactive"
        return (
            f"[{self.member_id}] {self.name} | {self.email} | "
            f"Tier: {self.tier} | Loans: {len(self.active_loan_ids)}/{self.loan_limit()} | {status}"
        )