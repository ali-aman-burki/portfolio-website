class Genre:
    FICTION = "Fiction"
    NON_FICTION = "Non-Fiction"
    SCIENCE = "Science"
    HISTORY = "History"
    BIOGRAPHY = "Biography"

    ALL = [FICTION, NON_FICTION, SCIENCE, HISTORY, BIOGRAPHY]
    @staticmethod
    def is_valid(genre):
        return genre in Genre.ALL


class Book:
    def __init__(self, book_id, title, author, genre, year, copies):
        self.book_id = book_id
        self.title = title
        self.author = author
        self.genre = genre
        self.year = year
        self.total_copies = copies
        self.available_copies = copies
    
    def is_available(self):
        return self.available_copies > 0

    def checkout(self):
        if self.available_copies > 0:
            self.available_copies -= 1
            return True
        return False

    def returning(self):
        if self.available_copies < self.total_copies:
            self.available_copies += 1
            return True
        return False

    def display(self):
        return (
            f"[{self.book_id}] \"{self.title}\" by {self.author} "
            f"({self.year}) | Genre: {self.genre} | "
            f"Available: {self.available_copies}/{self.total_copies}"
        )