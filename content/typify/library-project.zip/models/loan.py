class LoanStatus:
    ACTIVE = "Active"
    RETURNED = "Returned"
    OVERDUE = "Overdue"


class Loan:
    def __init__(self, loan_id, book_id, member_id, checkout_date, due_date):
        self.loan_id = loan_id
        self.book_id = book_id
        self.member_id = member_id
        self.checkout_date = checkout_date
        self.due_date = due_date
        self.return_date = None
        self.status = LoanStatus.ACTIVE

    def mark_returned(self, return_date):
        self.return_date = return_date
        self.status = LoanStatus.RETURNED

    def mark_overdue(self):
        if self.status == LoanStatus.ACTIVE:
            self.status = LoanStatus.OVERDUE

    def is_active(self):
        return self.status in (LoanStatus.ACTIVE, LoanStatus.OVERDUE)

    def days_on_loan(self, current_date):
        co = self._parse_date(self.checkout_date)
        cur = self._parse_date(current_date)
        return (cur - co).days

    def _parse_date(self, date_str):
        parts = date_str.split("-")
        year = int(parts[0])
        month = int(parts[1])
        day = int(parts[2])
        return _SimpleDate(year, month, day)

    def display(self):
        ret = self.return_date if self.return_date else "N/A"
        return (
            f"[{self.loan_id}] Book: {self.book_id} | Member: {self.member_id} | "
            f"Out: {self.checkout_date} | Due: {self.due_date} | "
            f"Returned: {ret} | Status: {self.status}"
        )


class _SimpleDate:
    DAYS_IN_MONTH = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

    def __init__(self, year, month, day):
        self.year = year
        self.month = month
        self.day = day

    def _to_days(self):
        total = self.year * 365 + self.year // 4
        for m in range(1, self.month):
            total += self.DAYS_IN_MONTH[m]
        total += self.day
        return total

    def __sub__(self, other):
        return _DayDelta(self._to_days() - other._to_days())


class _DayDelta:
    def __init__(self, days):
        self.days = days