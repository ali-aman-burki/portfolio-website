from sqlalchemy.orm import Session
from models import User

def get_username(db, user_id):
    user = db.query(User).filter(User.id == user_id).first()
    return user.name