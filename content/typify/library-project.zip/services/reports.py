from models.book import Book
from models.member import Member
from models.loan import Loan, LoanStatus
from services.catalog import Catalog
from services.lending import LendingService


class ReportLine:
    def __init__(self, label, value):
        self.label = label
        self.value = value

    def format(self):
        return f"  {self.label:<30} {self.value}"


class Report:
    def __init__(self, title):
        self.title = title
        self.lines = []
        self.sections = []

    def add_stat(self, label, value):
        self.lines.append(ReportLine(label, value))

    def add_section(self, heading, entries):
        self.sections.append((heading, entries))

    def render(self):
        border = "=" * 60
        output_parts = [border, f"  {self.title}", border]
        for line in self.lines:
            output_parts.append(line.format())
        for heading, entries in self.sections:
            output_parts.append("")
            output_parts.append(f"  -- {heading} --")
            if entries:
                for entry in entries:
                    output_parts.append(f"    {entry}")
            else:
                output_parts.append("    (none)")
        output_parts.append(border)
        return "\n".join(output_parts)


class ReportService:
    def __init__(self, catalog, lending):
        self._catalog = catalog
        self._lending = lending

    def inventory_report(self):
        report = Report("INVENTORY REPORT")
        all_books = self._catalog.all_books()
        available = self._catalog.available_books()
        total_copies = sum(b.total_copies for b in all_books)
        available_copies = sum(b.available_copies for b in all_books)

        report.add_stat("Total titles:", str(self._catalog.total_books()))
        report.add_stat("Total copies:", str(total_copies))
        report.add_stat("Available copies:", str(available_copies))
        report.add_stat("Checked out copies:", str(total_copies - available_copies))

        genre_counts = {}
        for book in all_books:
            genre_counts[book.genre] = genre_counts.get(book.genre, 0) + 1

        entries = [f"{genre}: {count} titles" for genre, count in genre_counts.items()]
        report.add_section("Books by Genre", entries)
        report.add_section("Unavailable Titles", [b.display() for b in all_books if not b.is_available()])
        return report

    def member_report(self):
        report = Report("MEMBER REPORT")
        members = self._lending.all_members()
        active = [m for m in members if m.is_active]
        inactive = [m for m in members if not m.is_active]

        report.add_stat("Total members:", str(len(members)))
        report.add_stat("Active members:", str(len(active)))
        report.add_stat("Inactive members:", str(len(inactive)))

        heavy = [m for m in active if len(m.active_loan_ids) > 0]
        report.add_section("Members with active loans", [m.display() for m in heavy])
        return report

    def loans_report(self, today):
        report = Report("LOANS REPORT")
        all_loans = self._lending.loan_history()
        active = self._lending.active_loans()
        overdue = self._lending.mark_overdue_loans(today)
        returned = [l for l in all_loans if l.status == LoanStatus.RETURNED]

        report.add_stat("Total loans ever:", str(len(all_loans)))
        report.add_stat("Currently active:", str(len(active)))
        report.add_stat("Overdue:", str(len(overdue)))
        report.add_stat("Returned:", str(len(returned)))

        report.add_section("Overdue Loans", [l.display() for l in overdue])
        return report

    def popular_books_report(self):
        report = Report("POPULAR BOOKS REPORT")
        all_loans = self._lending.loan_history()

        borrow_counts = {}
        for loan in all_loans:
            borrow_counts[loan.book_id] = borrow_counts.get(loan.book_id, 0) + 1

        sorted_books = sorted(borrow_counts.items(), key=lambda pair: pair[1], reverse=True)
        top = sorted_books[:5]

        entries = []
        for book_id, count in top:
            book = self._catalog.find_by_id(book_id)
            if book is not None:
                entries.append(f"{book.title} ({book.author}) — borrowed {count} time(s)")

        report.add_stat("Unique titles borrowed:", str(len(borrow_counts)))
        report.add_section("Top 5 Most Borrowed", entries)
        return report