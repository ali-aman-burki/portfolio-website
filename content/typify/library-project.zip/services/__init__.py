from services.catalog import Catalog
from services.lending import LendingService
from services.reports import ReportService, Report