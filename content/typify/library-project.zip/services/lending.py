from models.book import Book
from models.member import Member
from models.loan import Loan, LoanStatus
from services.catalog import Catalog


class LendingService:
    LOAN_PERIOD_DAYS = 14

    def __init__(self, catalog):
        self._catalog = catalog
        self._members = {}
        self._loans = {}
        self._next_member_id = 1
        self._next_loan_id = 1

    def _generate_member_id(self):
        mid = f"MB{self._next_member_id:04d}"
        self._next_member_id += 1
        return mid

    def _generate_loan_id(self):
        lid = f"LN{self._next_loan_id:04d}"
        self._next_loan_id += 1
        return lid

    def _add_days(self, date_str, days):
        parts = date_str.split("-")
        year = int(parts[0])
        month = int(parts[1])
        day = int(parts[2])
        day += days
        days_in_months = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
        while day > days_in_months[month]:
            day -= days_in_months[month]
            month += 1
            if month > 12:
                month = 1
                year += 1
        return f"{year}-{month:02d}-{day:02d}"

    def register_member(self, name, email, tier):
        for m in self._members.values():
            if m.email == email:
                raise ValueError(f"Email already registered: {email}")
        member_id = self._generate_member_id()
        member = Member(member_id, name, email, tier)
        self._members[member_id] = member
        return member

    def deactivate_member(self, member_id):
        member = self._members.get(member_id)
        if member:
            member.deactivate()
            return True
        return False

    def find_member(self, member_id):
        return self._members.get(member_id)

    def all_members(self):
        return list(self._members.values())

    def checkout_book(self, member_id, book_id, today):
        member = self._members.get(member_id)
        if member is None:
            raise ValueError(f"Member not found: {member_id}")
        if not member.can_borrow():
            raise ValueError(f"Member {member_id} cannot borrow: inactive or at loan limit")

        book = self._catalog.find_by_id(book_id)
        if book is None:
            raise ValueError(f"Book not found: {book_id}")
        if not book.checkout():
            raise ValueError(f"Book {book_id} is not available")

        due_date = self._add_days(today, self.LOAN_PERIOD_DAYS)
        loan_id = self._generate_loan_id()
        loan = Loan(loan_id, book_id, member_id, today, due_date)
        self._loans[loan_id] = loan
        member.add_loan(loan_id)
        return loan

    def return_book(self, loan_id, today):
        loan = self._loans.get(loan_id)
        if loan is None:
            raise ValueError(f"Loan not found: {loan_id}")
        if not loan.is_active():
            raise ValueError(f"Loan {loan_id} is already closed")

        book = self._catalog.find_by_id(loan.book_id)
        if book is not None:
            book.returning()

        member = self._members.get(loan.member_id)
        if member is not None:
            member.remove_loan(loan_id)

        loan.mark_returned(today)
        return loan

    def mark_overdue_loans(self, today):
        overdue = []
        for loan in self._loans.values():
            if loan.status == LoanStatus.ACTIVE and loan.due_date < today:
                loan.mark_overdue()
                overdue.append(loan)
        return overdue

    def active_loans(self):
        return [l for l in self._loans.values() if l.is_active()]

    def loan_history(self):
        return list(self._loans.values())

    def loans_for_member(self, member_id):
        return [l for l in self._loans.values() if l.member_id == member_id]