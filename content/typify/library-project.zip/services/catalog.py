from models.book import Book, Genre


class Catalog:
    def __init__(self):
        self._books = {}
        self._next_id = 1

    def _generate_id(self):
        book_id = f"BK{self._next_id:04d}"
        self._next_id += 1
        return book_id

    def add_book(self, title, author, genre, year, copies):
        if not Genre.is_valid(genre):
            raise ValueError(f"Invalid genre: {genre}. Must be one of {Genre.ALL}")
        if copies < 1:
            raise ValueError("Copies must be at least 1")
        book_id = self._generate_id()
        book = Book(book_id, title, author, genre, year, copies)
        self._books[book_id] = book
        return book

    def remove_book(self, book_id):
        if book_id in self._books:
            del self._books[book_id]
            return True
        return False

    def find_by_id(self, book_id):
        return self._books.get(book_id)

    def find_by_title(self, title):
        title_lower = title.lower()
        return [b for b in self._books.values() if title_lower in b.title.lower()]

    def find_by_author(self, author):
        author_lower = author.lower()
        return [b for b in self._books.values() if author_lower in b.author.lower()]

    def find_by_genre(self, genre):
        return [b for b in self._books.values() if b.genre == genre]

    def available_books(self):
        return [b for b in self._books.values() if b.is_available()]

    def all_books(self):
        return list(self._books.values())

    def total_books(self):
        return len(self._books)