from models.book import Genre
from models.member import MemberTier
from services.catalog import Catalog
from services.lending import LendingService

def seed_catalog(catalog):
    catalog.add_book("The Great Gatsby", "F. Scott Fitzgerald", Genre.FICTION, 1925, 3)
    catalog.add_book("A Brief History of Time", "Stephen Hawking", Genre.SCIENCE, 1988, 2)
    catalog.add_book("Sapiens", "Yuval Noah Harari", Genre.HISTORY, 2011, 4)
    catalog.add_book("Steve Jobs", "Walter Isaacson", Genre.BIOGRAPHY, 2011, 2)
    catalog.add_book("1984", "George Orwell", Genre.FICTION, 1949, 5)
    catalog.add_book("The Selfish Gene", "Richard Dawkins", Genre.SCIENCE, 1976, 2)
    catalog.add_book("Educated", "Tara Westover", Genre.BIOGRAPHY, 2018, 3)
    catalog.add_book("Thinking, Fast and Slow", "Daniel Kahneman", Genre.NON_FICTION, 2011, 2)


def seed_members(lending):
    lending.register_member("Alice Johnson", "alice@example.com", MemberTier.PREMIUM)
    lending.register_member("Bob Smith", "bob@example.com", MemberTier.BASIC)
    lending.register_member("Carol White", "carol@example.com", MemberTier.STUDENT)
    lending.register_member("David Brown", "david@example.com", MemberTier.STUDENT)


def seed_loans(lending):
    lending.checkout_book("MB0001", "BK0001", "2025-05-01")
    lending.checkout_book("MB0001", "BK0002", "2025-05-03")
    lending.checkout_book("MB0002", "BK0003", "2025-05-10")
    lending.checkout_book("MB0003", "BK0001", "2025-05-12")
    lending.checkout_book("MB0004", "BK0005", "2025-04-01")

    lending.return_book("LN0001", "2025-05-14")
    lending.return_book("LN0003", "2025-05-20")