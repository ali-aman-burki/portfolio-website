import sys
sys.path.insert(0, ".")

from services.catalog import Catalog
from services.lending import LendingService
from services.reports import ReportService
from app.db import seed_catalog, seed_members, seed_loans


TODAY = "2025-05-27"


def section(title):
    print(f"\n{'#' * 60}")
    print(f"#  {title}")
    print(f"{'#' * 60}")


def demo_catalog(catalog):
    section("CATALOG SEARCH DEMO")

    print("\n--- All books ---")
    for book in catalog.all_books():
        print(book.display())

    print("\n--- Search by author: 'Harari' ---")
    for book in catalog.find_by_author("Harari"):
        print(book.display())

    print("\n--- Search by genre: Science ---")
    from models.book import Genre
    for book in catalog.find_by_genre(Genre.SCIENCE):
        print(book.display())

    print("\n--- Search by title: '1984' ---")
    for book in catalog.find_by_title("1984"):
        print(book.display())

    print("\n--- Available books ---")
    for book in catalog.available_books():
        print(book.display())


def demo_members(lending):
    section("MEMBER DEMO")
    for member in lending.all_members():
        print(member.display())


def demo_loans(lending):
    section("LOAN HISTORY")
    for loan in lending.loan_history():
        print(loan.display())

    section("ACTIVE LOANS")
    for loan in lending.active_loans():
        print(loan.display())

    section("LOANS FOR MEMBER MB0001")
    for loan in lending.loans_for_member("MB0001"):
        print(loan.display())


def demo_new_checkout(lend, cat):
    section("NEW CHECKOUT DEMO")

    try:
        loan = lend.checkout_book("MB0002", "BK0005", TODAY)
        book = cat.find_by_id("BK0005")
        print(f"Checked out: {loan.display()}")
        if book is not None:
            print(f"Book status: {book.display()}")
    except ValueError as e:
        print(f"Checkout failed: {e}")

    print("\n--- Attempting to exceed loan limit (Basic member, max 3) ---")
    try:
        lend.checkout_book("MB0002", "BK0006", TODAY)
        lend.checkout_book("MB0002", "BK0007", TODAY)
        lend.checkout_book("MB0002", "BK0008", TODAY)

        print("All checkouts succeeded")
    except ValueError as e:
        print(f"Expected error: {e}")


def demo_reports(report_service):
    section("REPORTS")
    print(report_service.inventory_report().render())
    print()
    print(report_service.member_report().render())
    print()
    print(report_service.loans_report(TODAY).render())
    print()
    print(report_service.popular_books_report().render())


def run():
    catalog = Catalog()
    lending = LendingService(catalog)
    report_service = ReportService(catalog, lending)

    seed_catalog(catalog)
    seed_members(lending)
    seed_loans(lending)

    demo_catalog(catalog)
    demo_members(lending)
    demo_loans(lending)
    demo_new_checkout(lending, catalog)
    demo_reports(report_service)


if __name__ == "__main__":
    run()